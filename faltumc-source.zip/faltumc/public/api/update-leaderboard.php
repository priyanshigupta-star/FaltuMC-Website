<?php
// Receives top-players data from server-tools/leaderboard.py and saves it
// as /leaderboard-live.json for the website to read.
//
// The secret key lives OUTSIDE the website folder so it is never public and
// is not overwritten when you re-upload the site. Create this file one level
// above public_html, named faltumc-secret.php, containing:
//     <?php return 'your-long-random-key';

header('Content-Type: application/json');

function fail($code, $msg) {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

$siteRoot = dirname(__DIR__);                // public_html
$keyFile  = dirname($siteRoot) . '/faltumc-secret.php';

if (!is_file($keyFile)) fail(500, 'faltumc-secret.php not found above the website folder');
$secret = require $keyFile;
if (!is_string($secret) || strlen($secret) < 16) fail(500, 'secret key must be at least 16 characters');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail(405, 'POST only');
$given = $_SERVER['HTTP_X_LEADERBOARD_KEY'] ?? '';
if (!hash_equals($secret, $given)) fail(403, 'wrong key');

$raw = file_get_contents('php://input', false, null, 0, 200000);
$data = json_decode($raw, true);
if (!is_array($data) || !is_array($data['boards'] ?? null)) fail(400, 'invalid data');

// Only keep the fields the website uses
$clean = ['updated' => gmdate('c'), 'boards' => []];
foreach (['playtime', 'player_kills', 'mob_kills'] as $board) {
    $rows = [];
    foreach (array_slice($data['boards'][$board] ?? [], 0, 10) as $row) {
        $name = (string)($row['name'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_.\-*]{1,32}$/', $name)) continue;
        $rows[] = [
            'name'  => $name,
            'uuid'  => preg_replace('/[^a-fA-F0-9\-]/', '', (string)($row['uuid'] ?? '')),
            'value' => max(0, (int)($row['value'] ?? 0)),
        ];
    }
    $clean['boards'][$board] = $rows;
}

$target = $siteRoot . '/leaderboard-live.json';
$tmp = $target . '.tmp';
if (file_put_contents($tmp, json_encode($clean)) === false || !rename($tmp, $target)) {
    fail(500, 'could not write leaderboard-live.json (check folder permissions)');
}

echo json_encode(['ok' => true, 'updated' => $clean['updated']]);
