# FaltuMC Website

React + Vite site for **play.faltumc.in**. All settings (IP, links, modes, rules) are in `src/config.js`.

```bash
npm install
npm run dev      # local preview at http://localhost:5173
npm run build    # production build in dist/
```

Pushing to `main` deploys to GitHub Pages automatically (`.github/workflows/deploy.yml`).

## Live player count
Comes from api.mcstatus.io. The site checks every 30 s and the API refreshes its data every 60 s. Nothing to set up.

## Uploading to a web host (Hostinger, cPanel, etc.)
```bash
npm run zip      # creates faltumc-website.zip
```
Upload the zip to `public_html` in the host's File Manager and extract it there.
Re-upload whenever you change something; the live leaderboard and secret key are not overwritten.

## Top players (auto-updating, real server data)
The script on the Minecraft server reads vanilla stats (`world/stats/*.json`) and POSTs
the top 10 to `api/update-leaderboard.php`, which saves `leaderboard-live.json`.
Until the first upload, the site shows sample data.

1. **Make a secret key** (any long random text), e.g.
   `python3 -c "import secrets; print(secrets.token_hex(24))"`
2. **On the web host**, create `faltumc-secret.php` one folder **above** `public_html`
   (next to it, not inside it):
   ```php
   <?php return 'PASTE-YOUR-KEY-HERE';
   ```
3. **On the Minecraft machine**, copy `server-tools/leaderboard.py` and test:
   ```bash
   LEADERBOARD_KEY=PASTE-YOUR-KEY-HERE python3 leaderboard.py \
     --post https://YOUR-DOMAIN/api/update-leaderboard.php \
     --server /path/to/survival --server /path/to/skyblock
   ```
   It should print `web host: 200 {"ok":true,...}`.
   (`--server` = folder with `server.properties`; repeat for each backend server.)
4. **Run it every 10 minutes** (`crontab -e`):
   ```
   */10 * * * * LEADERBOARD_KEY=PASTE-YOUR-KEY-HERE /usr/bin/python3 /path/to/leaderboard.py --post https://YOUR-DOMAIN/api/update-leaderboard.php --server /path/to/survival --server /path/to/skyblock
   ```

Boards: Playtime, Player Kills, Mob Kills (vanilla stats, 1.12 – latest, works on offline-mode servers).
The script also supports `--gist GIST_ID` (with `GITHUB_TOKEN`) or `--out file.json`.
