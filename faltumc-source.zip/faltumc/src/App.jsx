import { useCallback, useRef, useState } from "react";
import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import Modes from "./components/Modes.jsx";
import HowToJoin from "./components/HowToJoin.jsx";
import Leaderboard from "./components/Leaderboard.jsx";
import Ranks from "./components/Ranks.jsx";
import Vote from "./components/Vote.jsx";
import Rules from "./components/Rules.jsx";
import Faq from "./components/Faq.jsx";
import DiscordCta from "./components/DiscordCta.jsx";
import Footer from "./components/Footer.jsx";
import { CopyContext } from "./components/CopyIp.jsx";

export default function App() {
  const [toast, setToast] = useState("");
  const timer = useRef();

  const copy = useCallback(async (text) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setToast(`Copied ${text} ✔`);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(""), 2000);
  }, []);

  return (
    <CopyContext.Provider value={copy}>
      <a className="skip" href="#main">Skip to content</a>
      <Navbar />
      <main id="main">
        <Hero />
        <Modes />
        <Leaderboard />
        <HowToJoin />
        <Ranks />
        <Vote />
        <Rules />
        <Faq />
        <DiscordCta />
      </main>
      <Footer />
      <div className={`toast${toast ? " show" : ""}`} role="status" aria-live="polite">
        {toast}
      </div>
    </CopyContext.Provider>
  );
}
