import { CONFIG } from "../config.js";
import { IpCode, useCopy } from "./CopyIp.jsx";
import ExtLink from "./ExtLink.jsx";

export default function Footer() {
  const copy = useCopy();
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div>
          <img src={`${import.meta.env.BASE_URL}logo.png`} alt="FaltuMC" className="footer__logo" width="160" />
          <p>FaltuMC is a Minecraft server for everyone. Survival, Skyblock and PvP – all in one place.</p>
          <div className="socials">
            <ExtLink href={CONFIG.links.discord}>Discord</ExtLink>
            <ExtLink href={CONFIG.links.youtube}>YouTube</ExtLink>
            <ExtLink href={CONFIG.links.instagram}>Instagram</ExtLink>
          </div>
        </div>
        <div>
          <h4>Navigate</h4>
          <a href="#top">Home</a>
          <a href="#modes">Modes</a>
          <a href="#leaderboard">Top Players</a>
          <a href="#vote">Vote</a>
          <a href="#store">Store</a>
          <a href="#rules">Rules</a>
          <a href="#faq">FAQ</a>
        </div>
        <div>
          <h4>Play Now</h4>
          <p>Java: <IpCode ip={CONFIG.javaIp} /></p>
          <p>Bedrock: <IpCode ip={CONFIG.bedrockIp} /> : {CONFIG.bedrockPort}</p>
          <button className="btn btn--primary btn--sm" onClick={() => copy(CONFIG.javaIp)}>Copy IP</button>
        </div>
      </div>
      <div className="container footer__bottom">
        <span>© {new Date().getFullYear()} FaltuMC. All rights reserved.</span>
        <span>Not affiliated with Mojang AB or Microsoft.</span>
      </div>
    </footer>
  );
}
