import { RULES } from "../config.js";

export default function Rules() {
  return (
    <section className="section section--alt" id="rules">
      <div className="container">
        <p className="eyebrow">Rules</p>
        <h2>Keep it fun for everyone</h2>
        <ol className="rules">
          {RULES.map(([title, text]) => (
            <li key={title}><b>{title}</b> {text}</li>
          ))}
        </ol>
      </div>
    </section>
  );
}
