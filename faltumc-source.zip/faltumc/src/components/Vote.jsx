import { CONFIG } from "../config.js";
import ExtLink from "./ExtLink.jsx";

export default function Vote() {
  return (
    <section className="section" id="vote">
      <div className="container">
        <p className="eyebrow">Vote</p>
        <h2>Vote daily, earn rewards</h2>
        <p className="lead">Every vote helps FaltuMC grow and gives you crate keys and in-game money.</p>
        <div className="vote">
          {CONFIG.voteSites.map((s, i) => (
            <ExtLink key={s.url} className="vote__item" href={s.url}>
              <span>#{i + 1}</span><b>{s.name}</b><em>Vote →</em>
            </ExtLink>
          ))}
        </div>
      </div>
    </section>
  );
}
