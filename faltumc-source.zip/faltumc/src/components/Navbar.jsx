import { useEffect, useState } from "react";
import { CONFIG } from "../config.js";
import ExtLink from "./ExtLink.jsx";

const LINKS = [
  ["Home", "#top"],
  ["Modes", "#modes"],
  ["Top Players", "#leaderboard"],
  ["Store", "#store"],
  ["Vote", "#vote"],
  ["Rules", "#rules"],
  ["FAQ", "#faq"],
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const close = () => setOpen(false);

  return (
    <header className={`nav${scrolled ? " nav--scrolled" : ""}`} id="top">
      <div className="container nav__inner">
        <a href="#top" className="nav__brand">
          <img src={`${import.meta.env.BASE_URL}favicon.png`} alt="" width="36" height="36" />
          <span>Faltu<b>MC</b></span>
        </a>
        <button
          className="nav__toggle"
          aria-label="Open menu"
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          <span></span><span></span><span></span>
        </button>
        <nav className={`nav__links${open ? " open" : ""}`}>
          {LINKS.map(([label, href]) => (
            <a key={label} href={href} onClick={close}>{label}</a>
          ))}
          <ExtLink href={CONFIG.links.discord} className="btn btn--sm btn--discord" onClick={close}>
            Discord
          </ExtLink>
        </nav>
      </div>
    </header>
  );
}
