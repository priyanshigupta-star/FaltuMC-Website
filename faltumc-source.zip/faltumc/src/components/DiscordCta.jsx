import { CONFIG } from "../config.js";
import ExtLink from "./ExtLink.jsx";

export default function DiscordCta() {
  return (
    <section className="section">
      <div className="container">
        <div className="cta">
          <div>
            <h2>Join the community</h2>
            <p>Get updates, giveaways, events and support on our Discord server.</p>
          </div>
          <ExtLink href={CONFIG.links.discord} className="btn btn--discord btn--lg">Join Discord</ExtLink>
        </div>
      </div>
    </section>
  );
}
