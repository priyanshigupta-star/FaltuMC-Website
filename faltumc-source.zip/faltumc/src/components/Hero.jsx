import { CONFIG } from "../config.js";
import useServerStatus from "../hooks/useServerStatus.js";
import { useCopy } from "./CopyIp.jsx";
import ExtLink from "./ExtLink.jsx";

const STATUS_TEXT = {
  loading: "Checking server…",
  online: "Server is online",
  offline: "Server is offline",
  error: "Status unavailable",
};

export default function Hero() {
  const copy = useCopy();
  const status = useServerStatus(CONFIG.javaIp, CONFIG.statusRefreshSeconds);
  const dotClass =
    status.state === "online" ? "dot dot--on" : status.state === "loading" ? "dot" : "dot dot--off";

  return (
    <section className="hero">
      <div className="hero__bg" aria-hidden="true"></div>
      <div className="container hero__inner">
        <img className="hero__logo" src={`${import.meta.env.BASE_URL}logo.png`} alt="FaltuMC logo" width="900" height="523" />
        <p className="hero__tagline">
          Survival <i>●</i> Skyblock <i>●</i> PvP
        </p>

        <div className="ipcard">
          <div className="ipcard__status">
            <span className={dotClass}></span>
            <span>{STATUS_TEXT[status.state]}</span>
          </div>
          <div className="ipcard__row">
            <div>
              <small>JAVA EDITION</small>
              <code className="ip">{CONFIG.javaIp}</code>
            </div>
            <button className="btn btn--primary" onClick={() => copy(CONFIG.javaIp)}>Copy IP</button>
          </div>
          <div className="ipcard__row">
            <div>
              <small>BEDROCK EDITION</small>
              <code>
                <span className="ip">{CONFIG.bedrockIp}</span>{" "}
                <span className="port">Port: {CONFIG.bedrockPort}</span>
              </code>
            </div>
            <button className="btn btn--ghost" onClick={() => copy(CONFIG.bedrockIp)}>Copy IP</button>
          </div>
        </div>

        <div className="hero__cta">
          <a href="#join" className="btn btn--primary btn--lg">▶ Play Now</a>
          <ExtLink href={CONFIG.links.discord} className="btn btn--discord btn--lg">Join our Discord</ExtLink>
        </div>

        <div className="stats">
          <div className="stat"><b>{status.online ?? "--"}</b><span>Players Online</span>{status.state === "online" && <span className="stat__live">● live</span>}</div>
          <div className="stat"><b>{status.max ?? "--"}</b><span>Max Slots</span></div>
          <div className="stat stat--version"><b>{status.version ?? "--"}</b><span>Version</span></div>
        </div>
      </div>
    </section>
  );
}
