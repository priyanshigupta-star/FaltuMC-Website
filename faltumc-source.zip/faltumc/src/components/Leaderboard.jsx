import { useState } from "react";
import { CONFIG } from "../config.js";
import useLeaderboard from "../hooks/useLeaderboard.js";

const BOARDS = [
  { key: "playtime", label: "Playtime", format: (v) => `${Math.floor(v / 3600)}h ${Math.floor((v % 3600) / 60)}m` },
  { key: "player_kills", label: "Kills", format: (v) => v.toLocaleString() },
  { key: "mob_kills", label: "Mob Kills", format: (v) => v.toLocaleString() },
];

function timeAgo(iso) {
  const mins = Math.round((Date.now() - new Date(iso)) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  return hrs < 24 ? `${hrs}h ago` : new Date(iso).toLocaleDateString();
}

export default function Leaderboard() {
  const [active, setActive] = useState(BOARDS[0].key);
  const { data, error } = useLeaderboard(CONFIG.leaderboardUrl, CONFIG.leaderboardRefreshMinutes);
  const board = BOARDS.find((b) => b.key === active);
  const rows = data?.boards?.[active] ?? [];

  return (
    <section className="section section--alt" id="leaderboard">
      <div className="container container--narrow">
        <p className="eyebrow">Leaderboard</p>
        <h2>Top players</h2>

        <div className="tabs" role="tablist">
          {BOARDS.map((b) => (
            <button
              key={b.key}
              role="tab"
              aria-selected={active === b.key}
              className={`tab${active === b.key ? " tab--active" : ""}`}
              onClick={() => setActive(b.key)}
            >
              {b.label}
            </button>
          ))}
        </div>

        {!data && !error && <p className="lb__note">Loading leaderboard…</p>}
        {!data && error && <p className="lb__note">Leaderboard is unavailable right now.</p>}

        {data && (
          <>
            <ol className="lb">
              {rows.map((p, i) => (
                <li key={p.uuid || p.name} className={`lb__row lb__row--${i + 1}`}>
                  <span className="lb__rank">#{i + 1}</span>
                  <img
                    className="lb__head"
                    src={`https://mc-heads.net/avatar/${encodeURIComponent(p.name)}/40`}
                    alt=""
                    width="40"
                    height="40"
                    loading="lazy"
                  />
                  <span className="lb__name">{p.name}</span>
                  <span className="lb__value">{board.format(p.value)}</span>
                </li>
              ))}
              {rows.length === 0 && <p className="lb__note">No data yet.</p>}
            </ol>
            <p className="lb__note">
              {data.updated ? `Updated ${timeAgo(data.updated)} · refreshes automatically` : "Sample data – real stats coming soon"}
            </p>
          </>
        )}
      </div>
    </section>
  );
}
