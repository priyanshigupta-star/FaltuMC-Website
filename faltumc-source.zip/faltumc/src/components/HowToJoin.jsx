import { CONFIG } from "../config.js";
import { IpCode } from "./CopyIp.jsx";

export default function HowToJoin() {
  return (
    <section className="section" id="join">
      <div className="container">
        <p className="eyebrow">How to Join</p>
        <h2>Start playing in 3 steps</h2>
        <div className="steps">
          <div className="step">
            <span>1</span><h3>Copy the IP</h3>
            <p>Click <b>Copy IP</b> above, or type <IpCode ip={CONFIG.javaIp} /></p>
          </div>
          <div className="step">
            <span>2</span><h3>Add Server</h3>
            <p>Open Minecraft → <b>Multiplayer</b> → <b>Add Server</b> and paste the IP.</p>
          </div>
          <div className="step">
            <span>3</span><h3>Play!</h3>
            <p>Join, pick a mode from the lobby and have fun. Bedrock players use port <b>{CONFIG.bedrockPort}</b>.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
