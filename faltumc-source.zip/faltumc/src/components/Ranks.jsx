import { useEffect, useState } from "react";
import { CONFIG, RANKS } from "../config.js";
import ExtLink from "./ExtLink.jsx";

const img = (file) => `${import.meta.env.BASE_URL}ranks/${file}`;

function Lightbox({ images, index, onClose, onNav }) {
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onNav(1);
      if (e.key === "ArrowLeft") onNav(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose, onNav]);

  return (
    <div className="lightbox" onClick={onClose} role="dialog" aria-modal="true">
      <img src={img(images[index])} alt="Kit preview" onClick={(e) => e.stopPropagation()} />
      {images.length > 1 && (
        <>
          <button className="lightbox__nav lightbox__nav--prev" aria-label="Previous" onClick={(e) => { e.stopPropagation(); onNav(-1); }}>‹</button>
          <button className="lightbox__nav lightbox__nav--next" aria-label="Next" onClick={(e) => { e.stopPropagation(); onNav(1); }}>›</button>
          <span className="lightbox__count">{index + 1} / {images.length}</span>
        </>
      )}
      <button className="lightbox__close" aria-label="Close" onClick={onClose}>✕</button>
    </div>
  );
}

function RankCard({ rank, onOpen }) {
  const [shown, setShown] = useState(0);
  return (
    <article className={`rank${rank.featured ? " rank--featured" : ""}`} style={{ "--rank": rank.color }}>
      <div className="rank__head">
        <span className="rank__icon">{rank.icon}</span>
        <div>
          <h3>{rank.name}</h3>
          <p className="rank__tagline">{rank.tagline}</p>
        </div>
        <p className="rank__price">₹{rank.price}<small>/month</small></p>
      </div>

      <div className="rank__body">
        <button className="rank__kit" onClick={() => onOpen(rank.images, shown)} aria-label={`View ${rank.name} kit`}>
          <img src={img(rank.images[shown])} alt={`${rank.name} kit preview`} loading="lazy" />
          <span>🔍 View kit</span>
        </button>
        {rank.images.length > 1 && (
          <div className="rank__thumbs">
            {rank.images.map((file, i) => (
              <button
                key={file}
                className={i === shown ? "active" : ""}
                onClick={() => setShown(i)}
                aria-label={`Kit image ${i + 1}`}
              >
                <img src={img(file)} alt="" loading="lazy" />
              </button>
            ))}
          </div>
        )}

        <ul className="rank__perks">
          {rank.perks.map((p) => <li key={p}>{p}</li>)}
        </ul>
      </div>

      <ExtLink href={CONFIG.links.discord} className="btn rank__buy">
        Buy {rank.name} – open a ticket
      </ExtLink>
    </article>
  );
}

export default function Ranks() {
  const [box, setBox] = useState(null); // { images, index }
  const nav = (d) => setBox((b) => ({ ...b, index: (b.index + d + b.images.length) % b.images.length }));

  return (
    <section className="section section--alt" id="store">
      <div className="container">
        <p className="eyebrow">Store</p>
        <h2>Ranks</h2>
        <p className="lead">Support FaltuMC and unlock kits, homes, vaults and more. To buy, open a ticket on our Discord.</p>
        <div className="ranks">
          {RANKS.map((r) => (
            <RankCard key={r.id} rank={r} onOpen={(images, index) => setBox({ images, index })} />
          ))}
        </div>
      </div>
      {box && <Lightbox images={box.images} index={box.index} onClose={() => setBox(null)} onNav={nav} />}
    </section>
  );
}
