import { createContext, useContext } from "react";

export const CopyContext = createContext(() => {});
export const useCopy = () => useContext(CopyContext);

// Clickable IP text that copies itself
export function IpCode({ ip }) {
  const copy = useCopy();
  return (
    <code className="ip" title="Click to copy" onClick={() => copy(ip)}>
      {ip}
    </code>
  );
}
