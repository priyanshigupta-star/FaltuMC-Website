import { MODES } from "../config.js";

export default function Modes() {
  return (
    <section className="section" id="modes">
      <div className="container">
        <p className="eyebrow">Game Modes</p>
        <h2>Pick your adventure</h2>
        <div className="cards">
          {MODES.map((m) => (
            <article key={m.name} className={`card${m.featured ? " card--featured" : ""}`}>
              <div className="card__icon">{m.icon}</div>
              <h3>{m.name}</h3>
              <p>{m.text}</p>
              <ul>
                {m.perks.map((p) => <li key={p}>{p}</li>)}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
