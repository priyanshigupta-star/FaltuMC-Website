import { CONFIG } from "../config.js";
import { IpCode } from "./CopyIp.jsx";
import ExtLink from "./ExtLink.jsx";

export default function Faq() {
  const faqs = [
    ["How do I join FaltuMC?", <>Open Minecraft, go to Multiplayer → Add Server and enter <IpCode ip={CONFIG.javaIp} />.</>],
    ["Which versions are supported?", <>Java Edition {CONFIG.versions} and the latest Bedrock Edition.</>],
    ["Can I play on Bedrock / mobile / console?", <>Yes! Use IP <IpCode ip={CONFIG.bedrockIp} /> and port <b>{CONFIG.bedrockPort}</b>.</>],
    ["Is the server free?", <>Yes, FaltuMC is 100% free to play. Ranks are optional and only give extra perks.</>],
    ["How do I get help or report a player?", <>Join our <ExtLink href={CONFIG.links.discord}>Discord</ExtLink> and open a ticket – our staff will help you.</>],
  ];

  return (
    <section className="section" id="faq">
      <div className="container container--narrow">
        <p className="eyebrow">FAQ</p>
        <h2>Frequently asked questions</h2>
        {faqs.map(([q, a]) => (
          <details key={q}>
            <summary>{q}</summary>
            <p>{a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
