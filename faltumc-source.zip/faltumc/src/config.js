/* =========================================================
   FaltuMC website config — EDIT THESE VALUES
   ========================================================= */
export const CONFIG = {
  javaIp: "play.faltumc.in", // your Java server address
  bedrockIp: "play.faltumc.in", // your Bedrock server address
  bedrockPort: "19132",
  versions: "1.12.2 – 1.21.11",
  links: {
    discord: "https://discord.faltumc.in/",
    youtube: "https://youtube.com/@realgaming90",
    instagram: "https://instagram.com/faltumc90",
  },
  // Top players JSON written by api/update-leaderboard.php on the web host.
  // If it doesn't exist yet, the site falls back to the sample public/leaderboard.json.
  leaderboardUrl: "leaderboard-live.json",
  statusRefreshSeconds: 30,
  leaderboardRefreshMinutes: 5,
  voteSites: [
    { name: "Minecraft-MP", url: "https://minecraft-mp.com/" },
    { name: "TopG", url: "https://topg.org/minecraft-servers/" },
    { name: "Minecraft Servers", url: "https://minecraftservers.org/" },
  ],
};

export const MODES = [
  {
    icon: "⛏️",
    name: "Survival",
    text: "Classic survival with land claims, player economy, shops, jobs and a friendly community. Build your base, trade and grow.",
    perks: ["Land claims & grief protection", "Player shops & economy", "Custom events"],
  },
  {
    icon: "🏝️",
    name: "Skyblock",
    featured: true,
    text: "Start on a tiny island in the sky and expand it into an empire. Grind generators, complete challenges and top the island leaderboard.",
    perks: ["Island upgrades & minions", "Challenges & rewards", "Island top leaderboard"],
  },
  {
    icon: "⚔️",
    name: "PvP",
    text: "Test your skills in duels, kit PvP and FFA arenas. Climb the ranks and prove you are the best fighter on FaltuMC.",
    perks: ["1v1 Duels & FFA", "Custom kits", "Ranked matchmaking"],
  },
];

export const RULES = [
  ["No hacking or cheating.", "No hacked clients, x-ray, auto-clickers or exploits."],
  ["Be respectful.", "No abuse, racism, harassment or spamming in chat."],
  ["No griefing.", "Don't destroy or steal from builds that aren't yours."],
  ["No advertising.", "Don't promote other servers or links."],
  ["No scamming.", "Trades must be fair and honest."],
  ["Listen to staff.", "Staff decisions are final. Appeal on Discord."],
];

const COMMON_PERKS = ["/repair command", "/enderchest command", "/kittycannon command"];

// Ranks shown in the Store section (cheapest first). Images live in public/ranks/
export const RANKS = [
  {
    id: "guardian", name: "Guardian", price: 30, color: "#4fc3f7", icon: "🛡️",
    tagline: "Protector of the Players",
    perks: [...COMMON_PERKS, "3 Homes", "3 Vaults", "/kit guardian"],
    images: ["guardian.jpg"],
  },
  {
    id: "venom", name: "Venom", price: 50, color: "#76ff03", icon: "💊",
    tagline: "Poison the players",
    perks: [...COMMON_PERKS, "4 Homes", "5 Vaults", "/kit venom"],
    images: ["venom.jpg"],
  },
  {
    id: "void", name: "Void", price: 70, color: "#b388ff", icon: "🗡️",
    tagline: "Throw players in void..",
    perks: [...COMMON_PERKS, "6 Homes", "7 Vaults", "/kit void"],
    images: ["void.jpg"],
  },
  {
    id: "destroyer", name: "Destroyer", price: 100, color: "#ff7043", icon: "🚀",
    tagline: "One goal – Destroy",
    perks: [...COMMON_PERKS, "8 Homes", "9 Vaults", "/kit destroyer"],
    images: ["destroyer.jpg"],
  },
  {
    id: "eternal", name: "Eternal", price: 200, color: "#ff4081", icon: "🎲",
    tagline: "Eternal as the darkness",
    perks: [...COMMON_PERKS, "10 Homes", "10 Vaults", "/kit eternal"],
    images: ["eternal.jpg"],
  },
  {
    id: "paradox", name: "Paradox", price: 300, color: "#ffd740", icon: "⌚",
    tagline: "Time is always under control",
    perks: [...COMMON_PERKS, "12 Homes", "12 Vaults", "/kit paradox"],
    images: ["paradox.jpg"],
  },
  {
    id: "custom", name: "Custom", price: 650, color: "#ff5252", icon: "👑", featured: true,
    tagline: "Your name. Your colour. Everything.",
    perks: [
      "Access to all ranks, kits and perks above",
      "Custom rank name",
      "Custom rank colour",
      "Extra perks",
    ],
    images: ["custom.jpg", "paradox.jpg", "eternal.jpg", "destroyer.jpg", "void.jpg", "venom.jpg", "guardian.jpg"],
  },
];
