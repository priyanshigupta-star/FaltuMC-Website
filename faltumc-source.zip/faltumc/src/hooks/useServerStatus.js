import { useEffect, useState } from "react";

// Live status from https://api.mcstatus.io (their cache refreshes every 60s)
export default function useServerStatus(ip, refreshSeconds = 30) {
  const [status, setStatus] = useState({ state: "loading" });

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const res = await fetch(`https://api.mcstatus.io/v2/status/java/${ip}`);
        const data = await res.json();
        if (cancelled) return;
        setStatus(
          data.online
            ? {
                state: "online",
                online: data.players?.online ?? 0,
                max: data.players?.max ?? "--",
                version: (data.version?.name_clean || "--").replace(/^\S+\s/, ""),
                updated: new Date(),
              }
            : { state: "offline", online: 0 }
        );
      } catch {
        if (!cancelled) setStatus((s) => (s.state === "online" ? s : { state: "error" }));
      }
    }
    load();
    const id = setInterval(load, refreshSeconds * 1000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [ip, refreshSeconds]);

  return status;
}
