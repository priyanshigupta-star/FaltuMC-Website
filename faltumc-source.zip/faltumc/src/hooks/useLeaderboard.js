import { useEffect, useState } from "react";

const SAMPLE = `${import.meta.env.BASE_URL}leaderboard.json`;

async function fetchJson(src) {
  // cache-buster so we always get the newest file
  const res = await fetch(`${src}${src.includes("?") ? "&" : "?"}t=${Date.now()}`);
  if (!res.ok) throw new Error(res.status);
  return res.json();
}

// Loads the live leaderboard, falling back to the bundled sample if it isn't there yet
export default function useLeaderboard(url, refreshMinutes = 5) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      for (const src of url ? [url, SAMPLE] : [SAMPLE]) {
        try {
          const json = await fetchJson(src);
          if (!cancelled) {
            setData(json);
            setError(false);
          }
          return;
        } catch {
          // try the next source
        }
      }
      if (!cancelled) setError(true);
    }
    load();
    const id = setInterval(load, refreshMinutes * 60000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [url, refreshMinutes]);

  return { data, error };
}
