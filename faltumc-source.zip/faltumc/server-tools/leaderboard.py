#!/usr/bin/env python3
"""
FaltuMC top-players exporter.

Reads Minecraft's built-in player statistics (world/stats/<uuid>.json) from one
or more worlds/servers, builds top-10 lists, and either writes them to a file
or uploads them to a GitHub Gist that the website reads.

No plugin needed. Python 3.8+, standard library only.

Examples
  # send to your web host (run on the Minecraft server, e.g. every 10 min via cron)
  LEADERBOARD_KEY=your-secret python3 leaderboard.py \
      --post https://faltumc.in/api/update-leaderboard.php \
      --server /home/mc/survival --server /home/mc/skyblock

  # or upload to a GitHub gist
  GITHUB_TOKEN=ghp_xxx python3 leaderboard.py --gist GIST_ID \
      --server /home/mc/survival --server /home/mc/skyblock

  # just write a file (to test)
  python3 leaderboard.py --server /home/mc/survival --out leaderboard.json
"""
import argparse
import glob
import json
import os
import sys
import urllib.error
import urllib.request
from collections import defaultdict
from datetime import datetime, timezone

TOP_N = 10

# (board, modern 1.13+ key, pre-1.17 modern key, legacy 1.12 key, divisor)
STATS = [
    ("playtime", "minecraft:play_time", "minecraft:play_one_minute", "stat.playOneMinute", 20),  # ticks -> seconds
    ("player_kills", "minecraft:player_kills", None, "stat.playerKills", 1),
    ("mob_kills", "minecraft:mob_kills", None, "stat.mobKills", 1),
]


def find_stats_dirs(server_dir):
    # level-name may not be "world", so look for any */stats folder
    return [d for d in glob.glob(os.path.join(server_dir, "*", "stats")) if os.path.isdir(d)]


def load_names(server_dirs):
    names = {}
    for sd in server_dirs:
        path = os.path.join(sd, "usercache.json")
        try:
            with open(path, encoding="utf-8") as f:
                for entry in json.load(f):
                    names[entry["uuid"]] = entry["name"]
        except (OSError, ValueError, KeyError):
            pass
    return names


def read_player_stats(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    custom = data.get("stats", {}).get("minecraft:custom", {})
    out = {}
    for board, key, old_key, legacy_key, div in STATS:
        raw = custom.get(key) or (custom.get(old_key) if old_key else 0) or data.get(legacy_key, 0)
        out[board] = int(raw or 0) // div
    return out


def build(server_dirs):
    totals = defaultdict(lambda: defaultdict(int))
    for sd in server_dirs:
        dirs = find_stats_dirs(sd)
        if not dirs:
            print(f"warning: no */stats folder found in {sd}", file=sys.stderr)
        for stats_dir in dirs:
            for path in glob.glob(os.path.join(stats_dir, "*.json")):
                uuid = os.path.basename(path)[:-5]
                try:
                    for board, value in read_player_stats(path).items():
                        totals[uuid][board] += value
                except (OSError, ValueError):
                    continue

    names = load_names(server_dirs)
    boards = {}
    for board, *_ in STATS:
        ranked = sorted(
            ((u, s[board]) for u, s in totals.items() if s[board] > 0 and u in names),
            key=lambda x: x[1],
            reverse=True,
        )[:TOP_N]
        boards[board] = [{"name": names[u], "uuid": u, "value": v} for u, v in ranked]

    return {"updated": datetime.now(timezone.utc).isoformat(), "boards": boards}


def upload_gist(gist_id, token, content):
    body = json.dumps({"files": {"leaderboard.json": {"content": content}}}).encode()
    req = urllib.request.Request(
        f"https://api.github.com/gists/{gist_id}",
        data=body,
        method="PATCH",
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "User-Agent": "faltumc-leaderboard",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as res:
        return res.status


def post_to_host(url, key, content):
    req = urllib.request.Request(
        url,
        data=content.encode(),
        method="POST",
        headers={
            "Content-Type": "application/json",
            "X-Leaderboard-Key": key,
            "User-Agent": "Mozilla/5.0 (faltumc-leaderboard)",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as res:
        return res.status, res.read().decode(errors="replace")


def main():
    ap = argparse.ArgumentParser(description="Export FaltuMC top players")
    ap.add_argument("--server", action="append", required=True,
                    help="Minecraft server folder (the one with server.properties). Repeat for multiple servers.")
    ap.add_argument("--out", help="write JSON to this file")
    ap.add_argument("--post", help="web host URL of api/update-leaderboard.php (needs LEADERBOARD_KEY env var)")
    ap.add_argument("--gist", help="GitHub Gist ID to update (needs GITHUB_TOKEN env var)")
    args = ap.parse_args()

    content = json.dumps(build(args.server), indent=1)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"wrote {args.out}")
    if args.gist:
        token = os.environ.get("GITHUB_TOKEN")
        if not token:
            sys.exit("GITHUB_TOKEN env var is not set")
        print("gist updated, HTTP", upload_gist(args.gist, token, content))
    if args.post:
        key = os.environ.get("LEADERBOARD_KEY")
        if not key:
            sys.exit("LEADERBOARD_KEY env var is not set")
        try:
            status, body = post_to_host(args.post, key, content)
            print("web host:", status, body)
        except urllib.error.HTTPError as e:
            sys.exit(f"web host error {e.code}: {e.read().decode(errors='replace')}")
    if not args.out and not args.gist and not args.post:
        print(content)


if __name__ == "__main__":
    main()
