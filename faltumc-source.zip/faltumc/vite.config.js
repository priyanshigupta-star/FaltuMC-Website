import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // relative base so the site works on GitHub Pages (username.github.io/repo/) and on a custom domain
  base: "./",
});
